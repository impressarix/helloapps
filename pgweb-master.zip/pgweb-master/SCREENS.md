# Screenshots

### Connect
<img src="screenshots/connect.png" />

### Browse table rows
<img src="screenshots/browse.png" />

### Write SQL queries
<img src="screenshots/query.png" />