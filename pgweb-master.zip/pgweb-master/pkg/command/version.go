package command

const VERSION = "0.9.11"

var (
	GitCommit string
	BuildTime string
)
